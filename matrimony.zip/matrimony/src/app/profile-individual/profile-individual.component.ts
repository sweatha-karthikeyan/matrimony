import { AfterViewInit, Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { closest, SwipeEventArgs, Touch, isNullOrUndefined} from '@syncfusion/ej2-base';

@Component({
  selector: 'app-profile-individual',
  templateUrl: './profile-individual.component.html',
  styleUrl: './profile-individual.component.scss'
})
export class ProfileIndividualComponent implements AfterViewInit {
  constructor(
    private dialogRef: MatDialogRef<ProfileIndividualComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
  ) { }


  ngAfterViewInit(): void {
    let ele = document?.getElementById('horizontal_product');
    this.swipeable();
    if (ele) {
      new Touch(ele, { swipe: this.touchSwipeHandler });
      let cards: NodeList = document.querySelectorAll('#horizontal_product .e-card');
      [].slice.call(cards).forEach((ele): void => {
          const imgElement = (ele as HTMLElement)?.querySelector('img');
          if (imgElement) {
              imgElement.onmousedown = () => { return false; };
          }
      });
    }
}

touchSwipeHandler(e: SwipeEventArgs): void {
  let ele: HTMLElement = <HTMLElement>closest(<Element>e.originalEvent.target, '.e-card');
  if (isNullOrUndefined(ele)) {
      return;
  }
  if (ele?.parentElement?.querySelector('.card-out')) {
      const cardOutElement = ele.parentElement.querySelector('.card-out');
      if (cardOutElement) {
          cardOutElement.classList.remove('card-out');
      }
  }
  if (ele.parentElement && ele.parentElement.querySelector('.card-out-left')) {
      const cardOutLeftElement = ele.parentElement.querySelector('.card-out-left');
      if (cardOutLeftElement) {
          cardOutLeftElement.classList.remove('card-out-left');
      }
  }
  e.swipeDirection === 'Right' ? ele.classList.add('card-out') : ele.classList.add('card-out-left');
  if (ele.parentElement) {
    ele.parentElement.insertBefore(ele, ele.parentElement.children[0]);
  }
  this.swipeable();
  ele.style.removeProperty('left');
}

  swipeable(): void {
    let fanStructuteCard: NodeList = document.querySelectorAll('#horizontal_product .e-card');
    let len: number = fanStructuteCard.length;
    [].slice.call(fanStructuteCard).forEach((ele: HTMLElement): void => {
        ele.style.removeProperty('transform');
    });
    let transformRatio: number = 2;
    let temp: number;
    let divide: number = (parseInt((len / 2).toString(), 10));
    temp = transformRatio;
    for (let i: number = divide - 1; i >= 0; i--) {
        (<HTMLElement>fanStructuteCard[i]).style.transform = 'rotate(' + (temp) + 'deg)';
        temp += transformRatio;
    }
    transformRatio = 2;
    temp = transformRatio;
    for (let i: number = divide + 1; i < len; i++) {
        (<HTMLElement>fanStructuteCard[i]).style.transform = 'rotate(' + (-temp) + 'deg)';
        temp += transformRatio;
    }
  }

  profileNotInterested(): void {
    window.alert('Not Interested');
  }

  profileInterested(): void {
    window.alert('Interested');
    this.swipeable();
  }
}
