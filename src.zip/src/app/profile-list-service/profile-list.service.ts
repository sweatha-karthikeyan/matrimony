import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ProfileListModel } from '../Models/profile-list.model';

@Injectable({
  providedIn: 'root'
})
export class ProfileListService {

  constructor(
    private http: HttpClient,
  ) { }

  getProfileList() {
    const URL = "http://localhost:3000/users"
    return this.http.get<ProfileListModel[]>(URL);
  }
}
