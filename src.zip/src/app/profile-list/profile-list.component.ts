import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ProfileListService } from '../profile-list-service/profile-list.service';
import { CarouselComponent } from '@syncfusion/ej2-angular-navigations';
import { ProfileIndividualComponent } from '../profile-individual/profile-individual.component';
import { MatDialog} from '@angular/material/dialog';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-profile-list',
  templateUrl: './profile-list.component.html',
  styleUrl: './profile-list.component.scss'
})
export class ProfileListComponent implements OnInit , OnDestroy{
  profileList: any[] = [];
  currentSlideIndex = 0;
  profileindividual$!: Subscription;
  @ViewChild("carousel") carousel!: CarouselComponent;
  constructor(
    private profileListService: ProfileListService,
    public dialogRef: MatDialog

  ) { }
  ngOnInit() {
    this.getProfileList();
  }

  public prevBtnClick() {
    this.carousel.prev();
  }

  public nextBtnClick() {
    this.carousel.next();
  }

  getProfileList():void {
    this.profileListService.getProfileList().subscribe((data: any) => {
      this.profileList = data;
      console.log(this.profileList);
    });
  }

  showProfile():void {
    this.profileindividual$?.unsubscribe();
    this.profileindividual$ =  this.dialogRef?.open(ProfileIndividualComponent, {
      height: '400px',
      width: '600px',
      data: {
        profileList: this.profileList,
        currentSlideIndex: this.currentSlideIndex
      },
    }).afterClosed().subscribe((result: boolean) => {
      this.profileindividual$?.unsubscribe();
    })
  }

  ngOnDestroy(): void {
    this.profileindividual$?.unsubscribe();
  }
}
